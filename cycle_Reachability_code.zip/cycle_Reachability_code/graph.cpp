#include "graph.h"
map<NODE_TYPE, DISTANCE_TYPE> bfs_return_spd_pairs(unordered_map<NODE_TYPE, set<NODE_TYPE>>& induced_subgraph, NODE_TYPE  node_num, NODE_TYPE  k, NODE_TYPE query_node1, set<NODE_TYPE>& cut_nodes)
{//store the final induced subgraph into reverse_adjacency_in_subgraph_left
	map<NODE_TYPE, DISTANCE_TYPE> result_pairs;
	int result = -1;
	DISTANCE_TYPE cur_distance = 0;
	set<NODE_TYPE> left_proprogate;
	set<NODE_TYPE> right_proprogate;
	//cur_proprogate.insert(query_node1);
	set<NODE_TYPE> node1_set;
	set<NODE_TYPE> node2_set;
	//set<NODE_TYPE> visited_nodes;

	set<NODE_TYPE> left_visited_nodes;

	//dag_min_induced_subgraph_reverse.insert(std::make_pair(query_node2, node2_set));// query node1's parent is empty
	left_visited_nodes.insert(query_node1);
	left_proprogate.insert(query_node1);
	//node1_set.insert(query_node1);
	//node2_set.insert(query_node2);

	//for (auto iter = adjacency_list[query_node1].begin(); iter != adjacency_list[query_node1].end(); iter++)
	//{
	//	left_proprogate.insert(*iter);
	//	reverse_adjacency_in_subgraph_left.insert(std::make_pair(*iter, node1_set));// store the first node
	//}


	//for (auto iter = adjacency_list_reverse[query_node2].begin(); iter != adjacency_list_reverse[query_node2].end(); iter++)
	//{
	//	right_proprogate.insert(*iter);
	//	reverse_adjacency_in_subgraph_right.insert(std::make_pair(*iter, node2_set));// store the first node
	//}

	bool left_skip = false;
	bool right_skip = false;
	int left_max_distance = k;// k - (k / 2);;
	int right_max_distance = k;// (k / 2);
	cur_distance = 0;
	while (true)
	{
		//left_skip = false;
		//right_skip = false;
		cur_distance++;
		if (cur_distance <= left_max_distance && !left_proprogate.empty())
		{
			set<NODE_TYPE> temp_proprogate;
			NODE_TYPE cur_node;
			for (auto iter = left_proprogate.begin(); iter != left_proprogate.end(); iter++)
			{
				cur_node = *iter;

				set<NODE_TYPE> temp_set;
				temp_set.insert(cur_node);
				auto iter_next = induced_subgraph.find(cur_node);
				if (iter_next == induced_subgraph.end())
				{
					continue;
				}
				for (auto iter2 = iter_next->second.begin(); iter2 != iter_next->second.end(); iter2++)
				{
					if (cut_nodes.find(*iter2) != cut_nodes.end())
					{//insert the node distance pair
						if (result_pairs.find(*iter2) == result_pairs.end())//first time to insert
						{
							result_pairs.insert(std::make_pair(*iter2, cur_distance));
						}
					}
					//if (right_proprogate.find(*iter2) != right_proprogate.end())// judge whether *iter is a meet node
					//{
					//	meet_nodes.insert(*iter2);
					//	//if (reverse_adjacency_in_subgraph_left.find(*iter2) == reverse_adjacency_in_subgraph_left.end())// not in index subgraph
					//	//{
					//	//	reverse_adjacency_in_subgraph_left.insert(std::make_pair(*iter2, temp_set));
					//	//}
					//	//else {
					//	//	reverse_adjacency_in_subgraph_left.find(*iter2)->second.insert(cur_node);
					//	//}
					//	//	
					//	//continue;
					//}
					set<NODE_TYPE> temp_set2;
					temp_set2.insert(*iter2);
					//if (dag_min_induced_subgraph_reverse.find(*iter2) == dag_min_induced_subgraph_reverse.end())// not in index subgraph
					//{
					//	dag_min_induced_subgraph_reverse.insert(std::make_pair(cur_node, temp_set2));
					//}
					//else {
					//	dag_min_induced_subgraph_reverse.find(cur_node)->second.insert(*iter2);
					//}
					if (left_visited_nodes.find(*iter2) != left_visited_nodes.end())//already visited
					{
						//reverse_adjacency_in_subgraph_left.find(*iter2)->second.insert(cur_node);
						continue;
					}

					left_visited_nodes.insert(*iter2);
					temp_proprogate.insert(*iter2);
				}
			}
			left_proprogate = temp_proprogate;
		}
		else {
			break;//left_skip = true;
		}
	}
	return result_pairs;
	//after left bfs, then we do a right bfs to get dag minimum induced subgraph
	//unordered_map<NODE_TYPE, set<NODE_TYPE>> dag_min_induced_subgraph_temp;
	//unordered_map<NODE_TYPE, set<NODE_TYPE>> dag_min_induced_subgraph_reverse_temp;
}


#pragma once
#ifndef DIRECTED_PPL_NS_CYCLE_REACHABILITY_H_
#define DIRECTED_PPL_NS_CYCLE_REACHABILITY_H_



#include <string>
#include <list>
#include <set>
#include <ctime>
#include <unordered_set>
#include <ostream>
#include <vector>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <time.h>  
#include "graph.h"

class cycle_reachability_undirected_index
{
public:
	int node_num;
	int cycle_num;
	unordered_map<NODE_TYPE, unordered_set<NODE_TYPE>> index;// node_id to cycle_id, denotes nodei belongs to cyclei
	cycle_reachability_undirected_index(int V)
	{
		node_num = V;
		cycle_num = 0;
	}
	bool construct_index_undirected(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse)
	{//construct BCC here
		//to code here
		unordered_set<NODE_TYPE> block_nodes;
		for (int i = 0; i < node_num; i++)
		{//enumeration for each vertex
			

		}
		return true;
	}
};

class Graph
{

	int V;    // No. of vertices 
	list<NODE_TYPE>* adj;    // A dynamic array of adjacency lists 
	int num_of_scc;
	// A Recursive DFS based function used by SCC() 

public:
	unordered_map<NODE_TYPE, NODE_TYPE> sccs;// vertex, sccid pair

	Graph(int V)
	{
		this->num_of_scc = 0;
		this->V = V;
		adj = new list<NODE_TYPE>[V];
		//sccs = new unordered_set<NODE_TYPE>[V];

	}


	Graph(int V, vector<NODE_TYPE >* adjacency_list)
	{
		this->num_of_scc = 0;
		//sccs = new unordered_set<NODE_TYPE>[V];

		this->V = V;
		adj = new list<NODE_TYPE>[V];
		for (int i = 0; i < V; i++)
		{
			for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				addEdge(i, *iter);
			}
		}
	}

	void addEdge(NODE_TYPE v, NODE_TYPE w)
	{
		adj[v].push_back(w);
	}

	// A recursive function that finds and prints strongly connected 
	// components using DFS traversal 
	// u --> The vertex to be visited next 
	// disc[] --> Stores discovery times of visited vertices 
	// low[] -- >> earliest visited vertex (the vertex with minimum 
	//             discovery time) that can be reached from subtree 
	//             rooted with current vertex 
	// *st -- >> To store all the connected ancestors (could be part 
	//           of SCC) 
	// stackMember[] --> bit/index array for faster check whether 
	//                  a node is in stack 
	void SCCUtil(NODE_TYPE u, NODE_TYPE disc[], NODE_TYPE low[], stack<NODE_TYPE>* st,
		bool stackMember[])
	{
		// A static variable is used for simplicity, we can avoid use 
		// of static variable by passing a pointer. 
		static int time = 0;

		// Initialize discovery time and low value 
		disc[u] = low[u] = ++time;
		st->push(u);
		stackMember[u] = true;

		// Go through all vertices adjacent to this 
		list<NODE_TYPE>::iterator i;
		for (i = adj[u].begin(); i != adj[u].end(); ++i)
		{
			int v = *i;  // v is current adjacent of 'u' 

			// If v is not visited yet, then recur for it 
			if (disc[v] == -1)
			{
				SCCUtil(v, disc, low, st, stackMember);

				// Check if the subtree rooted with 'v' has a 
				// connection to one of the ancestors of 'u' 
				// Case 1 (per above discussion on Disc and Low value) 
				low[u] = min(low[u], low[v]);
			}

			// Update low value of 'u' only of 'v' is still in stack 
			// (i.e. it's a back edge, not cross edge). 
			// Case 2 (per above discussion on Disc and Low value) 
			else if (stackMember[v] == true)
				low[u] = min(low[u], disc[v]);
		}

		// head node found, pop the stack and print an SCC 
		int w = 0;  // To store stack extracted vertices
		
		if (low[u] == disc[u])
		{
			vector<NODE_TYPE> temp;
			temp.clear();
			while (st->top() != u)
			{
				w = (int)st->top();
				//cout << w << " ";
				temp.push_back(w);
				stackMember[w] = false;
				st->pop();
			}
			w = (int)st->top();
			//cout << w << "\n";
			temp.push_back(w);
			if (temp.size() >= 2)
			{
				for (auto iter = temp.begin(); iter != temp.end(); iter++)
				{
					if (this->sccs.find(*iter) == this->sccs.end())
					{
						this->sccs.insert(std::make_pair(*iter, this->num_of_scc));
					}
				}
				this->num_of_scc++;
			}
			stackMember[w] = false;
			st->pop();
		}
	}
	void output_sccs()
	{
		for (auto iter = this->sccs.begin(); iter != this->sccs.end(); iter++)
		{
			cout << iter->first << " : pid" << iter->second << endl;
		}
		cout << "end of scc" << endl;
	}
	// The function to do DFS traversal. It uses SCCUtil() 
	void SCC()
	{
		NODE_TYPE* disc = new NODE_TYPE[V];
		NODE_TYPE* low = new NODE_TYPE[V];
		bool* stackMember = new bool[V];
		stack<NODE_TYPE>* st = new stack<NODE_TYPE>();

		// Initialize disc and low, and stackMember arrays 
		for (int i = 0; i < V; i++)
		{
			disc[i] = NIL;
			low[i] = NIL;
			stackMember[i] = false;
		}

		// Call the recursive helper function to find strongly 
		// connected components in DFS tree with vertex 'i' 
		for (int i = 0; i < V; i++)
			if (disc[i] == NIL)
				SCCUtil(i, disc, low, st, stackMember);
	}
};


class landmkark_index {
public:
	unordered_map<NODE_TYPE, unordered_map<NODE_TYPE, DIS_TYPE>> reach_index;
	unordered_map<NODE_TYPE, unordered_map<NODE_TYPE, DIS_TYPE>> unreach_index;
	unordered_set<NODE_TYPE> landmarks;
	unordered_set<NODE_TYPE>* scc_adjacency_list;
	unordered_set<NODE_TYPE>* scc_adjacency_list_reverse;
	void insert_reach_index(NODE_TYPE in_label, DIS_TYPE dis)
	{
		auto in_exist = reach_index.find(in_label);
		unordered_map<NODE_TYPE, DIS_TYPE> temp;
		temp.insert(std::make_pair(in_label, dis));
		if (in_exist == reach_index.end())//first time to insert
		{
			reach_index.insert(std::make_pair(in_label, temp));
		}
		else
		{
			in_exist->second.insert(std::make_pair(in_label, dis));
		}
	}
	void insert_unreach_index(NODE_TYPE out_label, DIS_TYPE dis)
	{
		auto out_exist = unreach_index.find(out_label);
		unordered_map<NODE_TYPE, DIS_TYPE> temp;
		temp.insert(std::make_pair(out_label, dis));
		if (out_exist == unreach_index.end())//first time to insert
		{
			unreach_index.insert(std::make_pair(out_label, temp));
		}
		else
		{
			out_exist->second.insert(std::make_pair(out_label, dis));
		}
	}
	bool construct_SCC(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		//construct SCC and prune vertices without in any SCC

	}
	bool construct_index(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse, NODE_TYPE node_num)
	{

	}
};
class ppl_ns_cr //ns indicates non simple and cr denotes cycle reachability
{
	unordered_map<NODE_TYPE, unordered_map<NODE_TYPE, DIS_TYPE>> in_labels;
	unordered_map<NODE_TYPE, unordered_map<NODE_TYPE, DIS_TYPE>> out_labels;
	void insert_in_label(NODE_TYPE in_label, DIS_TYPE dis)
	{
		auto in_exist = in_labels.find(in_label);
		unordered_map<NODE_TYPE,DIS_TYPE> temp;
		temp.insert(std::make_pair(in_label,dis));
		if (in_exist == in_labels.end())//first time to insert
		{
			in_labels.insert(std::make_pair(in_label, temp));
		}
		else
		{
			in_exist->second.insert(std::make_pair(in_label,dis));
		}
	}
	void insert_out_label(NODE_TYPE out_label, DIS_TYPE dis)
	{
		auto out_exist = out_labels.find(out_label);
		unordered_map<NODE_TYPE, DIS_TYPE> temp;
		temp.insert(std::make_pair(out_label,dis));
		if (out_exist == out_labels.end())//first time to insert
		{
			out_labels.insert(std::make_pair(out_label, temp));
		}
		else
		{
			out_exist->second.insert(std::make_pair(out_label,dis));
		}
	}
	bool construct_index(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		//auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			//if (temp_degree != 0)
			//{
			hot_degree hd1(i, temp_degree);
			hot_points.push_back(hd1);
			//}
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		//node_ranks.resize(node_num);
		NODE_TYPE temp_rank = 0;
		set<NODE_TYPE> already_indexed;
		uint32_t timeout = 6 * 3600 * 6;//6hours
		
	}
	uint32_t find_distance_ppl_reach(NODE_TYPE s, NODE_TYPE t)//
	{
		if (s == t)
		{
			return 1;
		}
		auto index_dst_in = in_labels.find(t);
		auto index_src_in = in_labels.find(s);
		auto index_dst_out = out_labels.find(t);
		auto index_src_out = out_labels.find(s);
		if (index_dst_in == in_labels.end() || index_src_in == in_labels.end() || index_dst_out == out_labels.end() || index_src_out == out_labels.end())
		{
			return 0;//no reach
		}
		for (auto pair : index_src_out->second)
		{
			if (index_dst_in->second.find(pair.first) != index_dst_in->second.end())
			{
				if ((index_dst_out->second.find(pair.first) != index_dst_out->second.end()) && (index_src_in->second.find(pair.first) != index_src_in->second.end()))//reverse reachability
				{
					return 1;
				}
			}
		}
		return 0;
	}
};


#endif
#include <iostream>
#include <chrono>
#include <ctime>
#include <random>
#include <string>
#include <fstream>
#include <limits>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <set>
#include <map>
#include <stack>
#include <chrono>
#include "BFS_prune.h"
#include "compare_algorithm.h"
//#include "graph.h"

using namespace std;



class Timer
{
public:
	Timer()
		: t1(res::zero())
		, t2(res::zero())
	{
		tic();
	}

	~Timer()
	{}

	void tic()
	{
		t1 = clock::now();
	}

	void toc(const char* str)
	{
		t2 = clock::now();
		std::cout << str << " time: "
			<< std::chrono::duration_cast<res>(t2 - t1).count() / 1e3 << "ms." << std::endl;
	}

private:
	typedef std::chrono::high_resolution_clock clock;
	typedef std::chrono::microseconds res;

	clock::time_point t1;
	clock::time_point t2;
};



static const uint32_t INF = numeric_limits<uint32_t>::max();
typedef mt19937 RandomGenerator;

void load_graph_data(string filename, vector<NODE_TYPE >* adjacency_list, vector<NODE_TYPE >* adjacency_list_reverse)
{
	char buffer[BUFFER_LENTH];
	ifstream inEdges(filename);
	if (!inEdges.is_open())
	{
		// cout << "Error opening file" << endl;
		exit(1);
	}
	NODE_TYPE  x, y;
	int i = 0;
	while (!inEdges.eof())
	{
		i++;
		inEdges.getline(buffer, BUFFER_LENTH);
		if (i <= 0)
		{
			continue;
		}
		extractEdges(buffer, x, y);
		if (x == y)
		{
			continue;//remove self-loop
		}
		adjacency_list[x].push_back(y);//directed graph, so we only push edge x y NODE_TYPE o x's adjacency list

		adjacency_list_reverse[y].push_back(x);
		//adjacency_list[y].push_back(x);
		//adjacency_list_reverse[x].push_back(y);//directed graph, so we only push edge x y NODE_TYPE o x's adjacency list

	}
	return;
}

void extractEdges(char str[], NODE_TYPE& x, NODE_TYPE& y)
{
	//char* end;
	char temp[256];
	NODE_TYPE  tempIndex = 0;
	NODE_TYPE  i = 0;
	for (i = 0; '0' <= str[i] && str[i] <= '9'; i++)
	{
		temp[tempIndex++] = str[i];
	}
	temp[tempIndex] = '\0';
	x = atoi(temp);
	tempIndex = 0;
	while (str[i + 1] != '\0' && str[i + 1] != '\t')
	{
		temp[tempIndex++] = str[++i];
	}
	temp[tempIndex] = '\0';
	y = atoi(temp);
	return;
}





int judge_two_k_repeat_paths_repeat_times(vector<NODE_TYPE>& path1, vector<NODE_TYPE>& path2)
{
	int repeat_times = 0;
	for (auto iter1 = path1.begin(); iter1 != path1.end(); iter1++)
	{
		for (auto iter2 = path2.begin(); iter2 != path2.end(); iter2++)
		{
			if (*iter1 == *iter2)
			{
				repeat_times++;
				break;
			}
		}
	}
	return repeat_times;
}

bool judge_k_repeat_paths(vector<NODE_TYPE>& temp_result_path, paths& result, int k)
{
	for (auto iter = result.path.begin(); iter != result.path.end(); iter++)
	{
		if (judge_two_k_repeat_paths_repeat_times(temp_result_path, *iter) > k)
		{
			return false;
		}
	}
	return true;
}

bool judge_containts_s_t(paths& result, NODE_TYPE s, NODE_TYPE t)
{
	for (auto iter = result.path.begin(); iter != result.path.end(); iter++)
	{
		if (judge_path_containts_s_t(*iter,s,t))
		{
			return true;
		}
	}
	return false;
}

bool judge_path_containts_s_t(vector<NODE_TYPE>& path, NODE_TYPE s, NODE_TYPE t)
{
	bool cs = false, ct = false;
	for (auto iter = path.begin(); iter != path.end(); iter++)
	{
		if (*iter == s)
		{
			cs = true;
		}
		else if (*iter == t)
		{
			ct = true;
		}
		if (cs && ct)
		{
			return true;
		}
	}
	return false;
}

void dfs_full_state(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path,set<NODE_TYPE>& visited_nodes)
{
	if (cur_node == query_node2)
	{

		//if meet a stop nodes
		vector<NODE_TYPE> temp_result_path(c_path);
		temp_result_path.push_back(cur_node);
		//judge whether is repeated or not
		if (judge_k_repeat_paths(temp_result_path, result, k))
		{
			result.push_back(temp_result_path);
			for (auto iter = temp_result_path.begin(); iter != temp_result_path.end(); iter++)
			{
				if (*iter != query_node1 && *iter != query_node2)
				{
					visited_nodes.insert(*iter);
				}
			}
			//cout << "find one" << endl;
		}
		return;
	}
	if (cur_distance >= dis_constraint)
	{
		return;
	}
	c_path.push_back(cur_node);
	set<NODE_TYPE> new_c_path_set(c_path_set);
	new_c_path_set.insert(cur_node);

	for (auto iter = adjacency_list[cur_node].begin(); iter != adjacency_list[cur_node].end(); iter++)
	{
		if (c_path_set.find(*iter) != c_path_set.end())// there is a repeat node or *iter cannot reach dst
		{
			continue;
		}
		else if (visited_nodes.find(*iter) != visited_nodes.end())
		{
			continue;
		}
		dfs_full_state(adjacency_list, *iter, query_node1, query_node2, k, dis_constraint, result, new_c_path_set, cur_distance + 1, c_path,visited_nodes);
		//c_path_set.erase(*iter);
	}
	//c_path_set.erase(*iter);
}


void dfs_modified_dfs(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, set<NODE_TYPE>& visited_nodes,int& full_state, set<NODE_TYPE>& block_nodes)
{
	if (full_state == 2)//back state
	{
		if (c_path.size() > (k - 1))
		{
			return;
		}
		else if (c_path.size() == (k - 1))
		{
			full_state = 1;
		}

	}
	if (full_state == 1 && c_path.size() < (k - 1))
	{
		full_state = 0;
		visited_nodes.clear();
	}
	
	if (cur_node == query_node2)
	{

		//if meet a stop nodes
		vector<NODE_TYPE> temp_result_path(c_path);
		temp_result_path.push_back(cur_node);
		//judge whether is repeated or not
		if (judge_k_repeat_paths(temp_result_path, result, k))
		{
			result.push_back(temp_result_path);
			for (auto iter = temp_result_path.begin(); iter != temp_result_path.end(); iter++)
			{
				if (*iter != query_node1 && *iter != query_node2)
				{
					visited_nodes.insert(*iter);
				}
			}
			full_state = 2;
			block_nodes.clear();
			//cout << "find one" << endl;
		}
		return;
	}
	if (cur_distance >= dis_constraint)
	{
		return;
	}
	c_path.push_back(cur_node);
	set<NODE_TYPE> new_c_path_set(c_path_set);
	new_c_path_set.insert(cur_node);

	for (auto iter = adjacency_list[cur_node].begin(); iter != adjacency_list[cur_node].end(); iter++)
	{
		if (c_path_set.find(*iter) != c_path_set.end())// there is a repeat node or *iter cannot reach dst
		{
			continue;
		}
		else if (visited_nodes.find(*iter) != visited_nodes.end())
		{
			continue;
		}
		else if (block_nodes.find(*iter) != block_nodes.end())
		{
			continue;
		}

		dfs_modified_dfs(adjacency_list, *iter, query_node1, query_node2, k, dis_constraint, result, new_c_path_set, cur_distance + 1, c_path, visited_nodes,full_state,block_nodes);
		//if(full_state !=2)
		//{
		//	if (*iter != query_node2)
		//		block_nodes.insert(*iter);
		//}
		if (full_state == 2)//back state
		{
			if (c_path.size() > (k - 1))
			{
				return;
			}
			else if (c_path.size() == (k - 1))
			{
				full_state = 1;
			}

		}

		if (full_state == 1 && c_path.size() < (k - 1))
		{
			full_state = 0;
			visited_nodes.clear();
		}
		//c_path_set.erase(*iter);
	}

	//c_path_set.erase(*iter);
}


void dfs_cycle_reachability_no_recursive(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, int cur_distance, vector<NODE_TYPE> c_path, bool& reach, int node_num, int dis_constraint)
{
	stack<NODE_TYPE> s;
	s.push(cur_node);
	stack<vector<NODE_TYPE>::iterator> s_iter;
	int* in_cur_paths = new int[node_num+1];
	for (int i = 0; i < node_num; i++)
	{
		in_cur_paths[i] = 0;
	}
	while (!s.empty())
	{
		//bool unblock = true;
		NODE_TYPE pre = s.top();
		int state = 1;// 1means dfs, 2 means back traversal
		if (pre == 88160)
		{
			//cout << " check" << endl;
		}
		if (c_path.size() >= dis_constraint)
		{
			state = 2;
		}
		if (in_cur_paths[pre])
		{//repeat vertex
			//s.pop();
			//s_iter.pop();
			state = 2;
			//unblock = false;
			//continue;
		}
		else if (pre == query_node1 && (!first_time))//should be the second time to touch query_node1
		{

			//if meet a stop nodes

			vector<NODE_TYPE> temp_result_path(c_path);
			temp_result_path.push_back(cur_node);
			//judge whether is repeated or not
			if (judge_path_containts_s_t(temp_result_path, query_node1, query_node2))
			{
				result.push_back(temp_result_path);
				for (auto iter_p = temp_result_path.begin(); iter_p != temp_result_path.end(); iter_p++)
				{
					cout << *iter_p << "\t";
				}
				cout << endl;
				reach = true;
				//return;
				//cout << "find one" << endl;
				//could return if in a cycle-reachability query
			}
			state = 2;
			//

		}
		c_path.push_back(pre);
		if (!first_time)
		{
			in_cur_paths[pre] ++;
		}
		//if (!first_time)
		//{
		//	in_cur_paths[pre] = true;
		//}

		if (state == 1)
		{
			auto iter = adjacency_list[pre].begin();
			if (iter == adjacency_list[pre].end())
			{
				state = 2;
				//continue;
			}
			else
			{

				s.push(*iter);
				s_iter.push(iter);

			}
			first_time = false;
		}

		if (state == 2)
		{
			//if (unblock)
			{
				in_cur_paths[s.top()] --;
			}
			s.pop();
			c_path.pop_back();
			auto iter = s_iter.top();
			NODE_TYPE temp_n = s.top();

			if (iter != adjacency_list[temp_n].end())
			{
				iter++;
			}
			// explore the next vertex, iter++ before entering or after, //before
			while ((iter == adjacency_list[temp_n].end())&& (!s_iter.empty()))
			{
				s_iter.pop();
				if (!c_path.empty())
				{
					//auto iter_temp = c_path_set.find(s.top());
					in_cur_paths[s.top()] --;
					c_path.pop_back();
				}
				s.pop();
				if (s.empty() || s_iter.empty())
				{
					break;
				}
				iter = s_iter.top();
				temp_n = s.top();
				if (iter != adjacency_list[temp_n].end())
				{
					iter++;
				}
			}
			if (s_iter.empty())
			{
				break;
			}
			else {

				s_iter.pop();
				s_iter.push(iter);
				s.push(*iter);
				//c_path.push_back(*iter);
				//c_path_set.insert(*iter);

			}
			continue;
			//return;
		}

	}
	delete[] in_cur_paths;
}


bool bfs_non_simple_cycle_reachability(vector<NODE_TYPE>* adj, NODE_TYPE cur_node, NODE_TYPE s, NODE_TYPE t, int dis_constraint, int node_num)
{
	bool* visited = new bool[node_num + 1];
	for (int i = 0; i <= node_num; i++)
	{
		visited[i] = false;
	}
	list<int> queue;

	// Mark the current node as visited and enqueue it 
	visited[s] = true;
	queue.push_back(s);

	// 'i' will be used to get all adjacent 
	// vertices of a vertex 
	while (!queue.empty())
	{
		// Dequeue a vertex from queue and print it 
		s = queue.front();
		//cout << s << " ";
		queue.pop_front();

		// Get all adjacent vertices of the dequeued 
		// vertex s. If a adjacent has not been visited,  
		// then mark it visited and enqueue it 
		for (auto i = adj[s].begin(); i != adj[s].end(); ++i)
		{
			if (!visited[*i])
			{
				visited[*i] = true;
				queue.push_back(*i);
			}
		}
	}
	return visited[t];
}


void dfs_cycle_reachability_with_block(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, bool& reach, set<NODE_TYPE>& blocks, bool& unblock)
{
	if (cur_distance >= TEST_HOP + 1)
	{
		//return;
	}
	if (cur_node == query_node1 && (!first_time))//should be the second time to touch query_node1
	{

		//if meet a stop nodes
		unblock = true;
		vector<NODE_TYPE> temp_result_path(c_path);
		temp_result_path.push_back(cur_node);
		//judge whether is repeated or not
		if (judge_path_containts_s_t(temp_result_path, query_node1, query_node2))
		{
			result.push_back(temp_result_path);
			reach = true;
			//cout << "find one" << endl;
		}
		return;
	}

	c_path.push_back(cur_node);
	set<NODE_TYPE> new_c_path_set(c_path_set);

	if (!first_time)
	{
		new_c_path_set.insert(cur_node);
		c_path_set.insert(cur_node);
	}
	first_time = false;

	for (auto iter = adjacency_list[cur_node].begin(); iter != adjacency_list[cur_node].end(); iter++)
	{
		if (c_path_set.find(*iter) != c_path_set.end())// there is a repeat node or *iter cannot reach dst
		{
			continue;
		}
		if (blocks.find(*iter) != blocks.end())
		{
			continue;
		}
		unblock = false;
		dfs_cycle_reachability_with_block(first_time, adjacency_list, *iter, query_node1, query_node2, result, new_c_path_set, cur_distance + 1, c_path, reach,blocks,unblock);
		if (unblock)
		{
			blocks.clear();
		}
		else {
			blocks.insert(*iter);
		}
		//c_path_set.erase(*iter);
	}
	//c_path_set.erase(*iter);
}


void dfs_cycle_reachability(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, bool& reach,int dis_constraint)
{
	if (cur_distance >= dis_constraint +1)
	{
		return;
	}
	if (cur_node == query_node1 && (!first_time))//should be the second time to touch query_node1
	{

		//if meet a stop nodes

		vector<NODE_TYPE> temp_result_path(c_path);
		temp_result_path.push_back(cur_node);
		//judge whether is repeated or not
		if (judge_path_containts_s_t(temp_result_path,query_node1,query_node2))
		{
			result.push_back(temp_result_path);
			reach = true;
			//cout << "find one" << endl;
		}
		return;
	}

	c_path.push_back(cur_node);
	set<NODE_TYPE> new_c_path_set(c_path_set);
	
	if (!first_time)
	{
		new_c_path_set.insert(cur_node);
		c_path_set.insert(cur_node);
	}
	first_time = false;

	for (auto iter = adjacency_list[cur_node].begin(); iter != adjacency_list[cur_node].end(); iter++)
	{
		if (c_path_set.find(*iter) != c_path_set.end())// there is a repeat node or *iter cannot reach dst
		{
			continue;
		}
		dfs_cycle_reachability(first_time,adjacency_list, *iter, query_node1, query_node2, result, new_c_path_set, cur_distance + 1, c_path,reach,dis_constraint);
		//c_path_set.erase(*iter);
	}
	//c_path_set.erase(*iter);
}

void dfs_baseline(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path)
{
	if (cur_node == query_node2)
	{

		//if meet a stop nodes
		if (c_path.size() > dis_constraint)
		{
			return;
		}
		vector<NODE_TYPE> temp_result_path(c_path);
		temp_result_path.push_back(cur_node);
		//judge whether is repeated or not
		if (judge_k_repeat_paths(temp_result_path, result,k))
		{
			result.push_back(temp_result_path);
			//cout << "find one" << endl;
		}
		return;
	}
	if (cur_distance > dis_constraint)
	{
		return;
	}
	c_path.push_back(cur_node);
	set<NODE_TYPE> new_c_path_set(c_path_set);
	new_c_path_set.insert(cur_node);

	for (auto iter = adjacency_list[cur_node].begin(); iter != adjacency_list[cur_node].end(); iter++)
	{
		if (c_path_set.find(*iter) != c_path_set.end())// there is a repeat node or *iter cannot reach dst
		{
			continue;
		}

		dfs_baseline(adjacency_list, *iter, query_node1, query_node2, k, dis_constraint, result, new_c_path_set, cur_distance + 1, c_path);
		//c_path_set.erase(*iter);
	}
	//c_path_set.erase(*iter);
}


paths diversify_baseline(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, int k, NODE_TYPE s, NODE_TYPE t)
{
	paths result;
	//not recursive dfs
	stack<NODE_TYPE> st;
	st.push(s);
	while (!st.empty())
	{
		NODE_TYPE tempN = st.top();
		for (auto iter = adjacency_list[tempN].begin(); iter != adjacency_list[tempN].end(); iter++)
		{

		}
	}
	return result;
}

void output_paths(paths& result)
{
	for (auto iter1 = result.path.begin(); iter1 != result.path.end(); iter1++)
	{
		for (auto iter2 = iter1->begin(); iter2 != iter1->end(); iter2++)
		{
			cout << *iter2 << "\t";
		}
		cout << endl;
	}
	cout << "end of paths output" <<endl;
}


int test_s_t_reachability_adj(vector<NODE_TYPE>* adjacency_list, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, set<NODE_TYPE> c_path_set)
{
	int cur_dis = 0;
	unordered_set<NODE_TYPE> cur_propagate;
	unordered_set<NODE_TYPE> visited_nodes;
	for (auto iter = c_path_set.begin(); iter != c_path_set.end(); iter++)
	{
		if ((*iter != query_node1) && (*iter != query_node2))
		{
			visited_nodes.insert(*iter);
		}
	}
	cur_propagate.insert(query_node1);
	while (cur_dis + c_path_set.size() < k)// the c_path_set does not include query_node1 so far
	{
		unordered_set<NODE_TYPE> temp_propagate;
		for (auto cur_node = cur_propagate.begin(); cur_node != cur_propagate.end(); cur_node++)
		{
			//auto iter_next = induced_graph.find(*cur_node);
			//if (iter_next == induced_graph.end())//no edges here
			//{
			//	continue;;

			for (auto iter = adjacency_list[*cur_node].begin(); iter != adjacency_list[*cur_node].end(); iter++)
			{
				if (visited_nodes.find(*iter) != visited_nodes.end())
				{
					continue;
				}
				if (*iter == query_node2)
				{
					return cur_dis + 1;
				}
				else {
					temp_propagate.insert(*iter);
				}
			}
			visited_nodes.insert(*cur_node);
		}
		cur_propagate = temp_propagate;
		cur_dis++;
	}
	return 0;
}

void test_algorithms(int k,int dis_constraint, string dataset, string query_dataset, string algorithm)
{
	//int k = 2;

	NODE_TYPE s = 1, t = 444232, cur_node = 0;

	ofstream test;
	//test.open("Amazon_result\\hp_result" + to_string(testi));
	//test << "test " << endl;

	//string dataset = "roadNet-TX.txt";

	ifstream count_file;
	ifstream inEdges, queries;
	NODE_TYPE  node_num;
	string count_name = dataset;
	//count_name += ".static";
	count_file.open(count_name);
	char tmp[BUFFER_LENTH];

	if (!count_file.is_open())
	{
		cout << "Error opening file : " << dataset << endl;
		return;
	}
	//configure the values of n and m 
	node_num = 0;
	int i = 0;
	NODE_TYPE x, y;
	while (!count_file.eof())
	{
		NODE_TYPE x, y;
		count_file.getline(tmp, BUFFER_LENTH);
		extractEdges(tmp, x, y);
		if (x > node_num)
		{
			node_num = x;
		}
		if (y > node_num)
		{
			node_num = y;
		}
	}
	//de_num++;
	node_num++;
	cout << node_num << " is the load node num " << endl;
	count_file.close();

	vector<NODE_TYPE >* adjacency_list = new vector<NODE_TYPE >[node_num + 1];
	vector<NODE_TYPE >* adjacency_list_reverse = new vector<NODE_TYPE >[node_num + 1];
	vector<NODE_TYPE >* adjacency_list_double = new vector<NODE_TYPE>[node_num + 1];


	vector<NODE_TYPE >* adjacency_list_induced = new vector<NODE_TYPE >[node_num + 1];
	vector<NODE_TYPE >* adjacency_list_reverse_induced = new vector<NODE_TYPE >[node_num + 1];

	string temp_static(dataset);
	//string temp_dynamic(dataset);
	clock_t base_start, base_end, full_end, modified_dfs_end, bcdfs_end, mbcdfs_end, inlw_mdfs_end, bcdfs_start;


	//temp_static += ".static"; 

	//temp_dynamic += "_" + to_string(k) + "_randomquery";
	load_graph_data(temp_static, adjacency_list, adjacency_list_reverse);
	cout << "end of load" << endl;
	paths result;// , result2, result3, result_ilmdfs;
	set<NODE_TYPE> c_path_set;
	int cur_distance = 0;// , dis_constraint = 6;
	//k = 3;
	vector<NODE_TYPE> c_path;
	set<NODE_TYPE> visited_nodes, block_nodes;

	s = 149810, t = 149783, cur_node = 0;
	//s = 1, t = 88160, cur_node = 0;

	queries.open(query_dataset);
	if (!queries.is_open())
	{
		cout << "Error opening file : " << query_dataset << endl;
		return;
	}
	ofstream runtime_file, result_file;
	runtime_file.open(dataset + "_" + to_string(k) + "_" + to_string(dis_constraint) + "_" + algorithm+"_runtime");
	result_file.open(dataset + "_" + to_string(k) + "_" + to_string(dis_constraint) + "_" + algorithm + "_result");
	if (!runtime_file.is_open())
	{
		cout << "Error opening file : runtime file" << endl;
		return;
	}
	if (!result_file.is_open())
	{
		cout << "Error opening file result file" << endl;
		return;
	}
	runtime_file << dataset + "_" + to_string(k) + "_" + to_string(dis_constraint) + "_" + algorithm + "_runtime" << endl;
	runtime_file << "runtime(s) \t index size(MB) \t #of index entries" << endl;

	result_file << dataset + "_" + to_string(k) + "_" + to_string(dis_constraint) + "_" + algorithm + "_result" << endl;
	int query_num = 0;

	/////preprocess
	Graph g(node_num, adjacency_list);

	g.SCC();
	for (int i = 0; i < node_num; i++)
	{
		if (g.sccs.find(i) == g.sccs.end())
		{//pruned
			continue;
		}
		for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
		{
			if (g.sccs.find(*iter) == g.sccs.end())
			{//pruned
				continue;
			}
			else {
				adjacency_list_induced[i].push_back(*iter);
			}
		}
		for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
		{
			if (g.sccs.find(*iter) == g.sccs.end())
			{//pruned
				continue;
			}
			else {
				adjacency_list_reverse_induced[i].push_back(*iter);
			}
		}
	}

	/////end of preprocess
	
	while (!queries.eof())
	{
		//NODE_TYPE x, y;
		result.clear();
		c_path_set.clear();
		cur_distance = 0;
		c_path.clear();
		block_nodes.clear();
		query_num++;
		queries.getline(tmp, BUFFER_LENTH);
		extractEdges(tmp, s, t);
		cout << query_num << "\t:\t" <<s <<" query " <<t << endl;
		base_start = clock();
		int full_state = 0;
		visited_nodes.clear();
		bool first_time = true;
		bool reach = false;
		BlockTree bt;

		if (algorithm == "dfs")//naive method
		{
			set<NODE_TYPE> block;
			bool unblock = false;
			dfs_cycle_reachability_with_block(first_time, adjacency_list, s, s, t, result, c_path_set, cur_distance, c_path, reach,block, unblock);// (adjacency_list, s, s, t, k, dis_constraint, result, c_path_set, cur_distance, c_path, visited_nodes);
		}
		else if (algorithm == "tpa")
		{
			if (g.sccs.find(s) == g.sccs.end() || g.sccs.find(t) == g.sccs.end())
			{
				;
			}
			else if (g.sccs.find(s)->second != g.sccs.find(t)->second)
			{
				;
			}
			else
			{
				pruned_subgraph_unordered_map_double_direction temp_pruned2;
				//temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
				temp_pruned2.construct_subgraph(adjacency_list_induced, adjacency_list_reverse_induced, node_num);
				CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
				//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
				//paths al_result, al_result2;
				//bcdfs_start = clock();
				int up_return = 0;
				//return the shorest path and check the reachability
				int t_s_distance = test_s_t_reachability_adj(adjacency_list, t, s, dis_constraint, c_path_set);
				int s_t_distance = test_s_t_reachability_adj(adjacency_list, s, t, dis_constraint, c_path_set);
				cout << t_s_distance << "is the t s distance" << endl;
				cout << s_t_distance << "is the s t distance" << endl;
				if (t_s_distance >= s_t_distance)
				{
					dfs_block.block_bfs_cycle_reachability(s, s, t, dis_constraint - t_s_distance, result, c_path_set, 0, c_path, dis_constraint, up_return,bt);
				}
				else
				{
					dfs_block.block_bfs_cycle_reachability(t, t, s, dis_constraint - s_t_distance, result, c_path_set, 0, c_path, dis_constraint, up_return,bt);

				}
				//dfs_block.block_bfs_cycle_reachability(s, s, t, dis_constraint, result, c_path_set, 0, c_path, dis_constraint, up_return, bt);

				//bt.output();
				cout << "end" << endl;
			}

		}
		else if (algorithm == "bot")
		{
			if (g.sccs.find(s) == g.sccs.end() || g.sccs.find(t) == g.sccs.end())
			{
				;
			}
			else if (g.sccs.find(s)->second != g.sccs.find(t)->second)
			{
				;
			}
			else
			{
				pruned_subgraph_unordered_map_double_direction temp_pruned2;
				//temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
				temp_pruned2.construct_subgraph(adjacency_list_induced, adjacency_list_reverse_induced, node_num);
				CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
				//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
				//paths al_result, al_result2;
				//bcdfs_start = clock();
				int up_return = 0;
				//BlockTree bt;
				//return the shorest path and check the reachability
				int t_s_distance = test_s_t_reachability_adj(adjacency_list, t,  s,  dis_constraint, c_path_set);
				int s_t_distance = test_s_t_reachability_adj(adjacency_list, s, t, dis_constraint, c_path_set);
				cout << t_s_distance << "is the t s distance" << endl;
				cout << s_t_distance << "is the s t distance" << endl;
				if (t_s_distance >= s_t_distance)
				{
					//dfs_block.block_bfs_cycle_reachability(s, s, t, dis_constraint - t_s_distance, result, c_path_set, 0, c_path, dis_constraint, up_return,bt);
				}
				else
				{
					//dfs_block.block_bfs_cycle_reachability(t, t, s, dis_constraint - s_t_distance, result, c_path_set, 0, c_path, dis_constraint, up_return,bt);

				}
				dfs_block.block_bfs_cycle_reachability(s, s, t, dis_constraint, result, c_path_set, 0, c_path, dis_constraint, up_return, bt);

				//bt.output();
				cout << "end" << endl;
			}
			
		}
		else if (algorithm == "bot+")
		{
			if (g.sccs.find(s) == g.sccs.end() || g.sccs.find(t) == g.sccs.end())
			{
				;
			}
			else if (g.sccs.find(s)->second != g.sccs.find(t)->second)
			{
				;
			}
			else
			{
				pruned_subgraph_unordered_map_double_direction temp_pruned2;
				//temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
				temp_pruned2.construct_subgraph(adjacency_list_induced, adjacency_list_reverse_induced, node_num);
				CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
				//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
				//paths al_result, al_result2;
				//bcdfs_start = clock();
				int up_return = 0;
				//BlockTree bt;
				//return the shorest path and check the reachability
				int t_s_distance = test_s_t_reachability_adj(adjacency_list, t, s, dis_constraint, c_path_set);
				int s_t_distance = test_s_t_reachability_adj(adjacency_list, s, t, dis_constraint, c_path_set);
				cout << t_s_distance << "is the t s distance" << endl;
				cout << s_t_distance << "is the s t distance" << endl;
				if (t_s_distance >= s_t_distance)
				{
					dfs_block.block_bfs_cycle_reachability_advanced(s, s, t, dis_constraint - t_s_distance, result, c_path_set, 0, c_path, dis_constraint, up_return, bt);
				}
				else
				{
					dfs_block.block_bfs_cycle_reachability_advanced(t, t, s, dis_constraint - s_t_distance, result, c_path_set, 0, c_path, dis_constraint, up_return, bt);

				}
				//dfs_block.block_bfs_cycle_reachability_advanced(s, s, t, dis_constraint, result, c_path_set, 0, c_path, dis_constraint, up_return, bt);

				//bt.output();
				cout << "end" << endl;
			}

		}
		else if (algorithm == "cet+")
		{
			//adjacency_list_induced->clear();
			if (g.sccs.find(s) == g.sccs.end() || g.sccs.find(t) == g.sccs.end())
			{
				;
			}
			else if(g.sccs.find(s)->second != g.sccs.find(t)->second)
			{
				;
			}
			else
			{
				pruned_subgraph_unordered_map_double_direction temp_pruned2;
				temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
				//temp_pruned2.construct_subgraph(adjacency_list_induced, adjacency_list_reverse_induced, node_num);
				CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
				//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
				//paths al_result, al_result2;
				//bcdfs_start = clock();
				dfs_block.dfs_find_k_paths_with_block_cycle_reachability(s, s, t, dis_constraint, result, c_path_set, 0, c_path, k);
			}
		}
		else if (algorithm == "dbfc_ns")//non simple cycles
		{
			bool reach1 = bfs_non_simple_cycle_reachability(adjacency_list, s, s, t, dis_constraint, node_num);
			bool reach2 = bfs_non_simple_cycle_reachability(adjacency_list, t, t, s, dis_constraint, node_num);
			reach = reach1 && reach2;
		}

		else if (algorithm == "dfs_two_bdfs")// non-simple
		{
			if (g.sccs.find(s) == g.sccs.end() || g.sccs.find(t) == g.sccs.end())
			{
				;
			}
			else if (g.sccs.find(s)->second != g.sccs.find(t)->second)
			{
				;
			}
			else
			{
				pruned_subgraph_unordered_map_double_direction temp_pruned2;
				//temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
				temp_pruned2.construct_subgraph(adjacency_list_induced, adjacency_list_reverse_induced, node_num);
				CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
				//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
				//paths al_result, al_result2;
				//bcdfs_start = clock();
				dfs_block.dfs_with_two_block_cycle_reachability(s, s, t, dis_constraint, result, c_path_set, 0, c_path, k);
			}
		}
		else if (algorithm == "cet")//baseline
		{
			pruned_subgraph_unordered_map_double_direction temp_pruned2;
			//temp_pruned2.construct_pruned_dag_min_subgraph_bcdfs(adjacency_list, adjacency_list_reverse, node_num, dis_constraint, s, t);
			temp_pruned2.construct_subgraph(adjacency_list, adjacency_list_reverse, node_num);
			CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num);
			//CB_DFS_induced dfs_block(temp_pruned2.dag_min_induced_subgraph, node_num,temp_pruned2.dst_distance);
			//paths al_result, al_result2;
			//bcdfs_start = clock();
			dfs_block.dfs_find_k_paths_with_block_cycle_reachability(s, s, t, dis_constraint, result, c_path_set, 0, c_path, k);

		}
	
		base_end = clock();
		//cout << bt.getIndexSizeInBytesM(adjacency_list,node_num)/1000000.0 << "MB" << endl;
		runtime_file  << double(base_end - base_start) / CLOCKS_PER_SEC <<  "\t" << bt.getIndexSizeInBytesM(adjacency_list, node_num) / 1000000.0 <<"\t" << bt.nums<< endl;


		result.output();
		result.write_to_file(dataset + "_" + to_string(k) + "_" + to_string(dis_constraint) + "_" + algorithm + "_raw_result");
		//result_file << result.get_path().size() << endl;
		if (result.get_path().size() > 0)
		{
			result_file << "True" << endl;
		}
		else
		{
			result_file << "False" << endl;
		}
	}
	delete[] adjacency_list;
	delete[] adjacency_list_reverse;
	delete[] adjacency_list_double;
	delete[] adjacency_list_reverse_induced;
	delete[] adjacency_list_induced;
	runtime_file.close();
	result_file.close();
	queries.close();
	//al_result2.output();
	//cout << al_result2.get_path().size() << endl;

}


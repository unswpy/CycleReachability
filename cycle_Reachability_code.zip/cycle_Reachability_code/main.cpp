#include <iostream>
#include "compare_algorithm.h"
using namespace std;
int main()
{

	//cout << "hello world" << endl;
	string dataset = "Amazon.txt.static";// "twitter_social.static";// "Amazon.static2";// "Amazon.txt.static";"Amazon.txt.static"; //
	string query_dataset = "Amazon.txt_3_randomquery"; //"twitter_social_3_randomquery";// Amazon.txt_3_randomquery";// "query_small";//"query.txt";// "query_test";//"query_test";//
	string algorithm = "bot+";//"cet, cet+, bot, bot+"
	int k = 10;
	test_algorithms(0,k,dataset,query_dataset, algorithm);
	cout << "end" << endl;
	return 0;
} 
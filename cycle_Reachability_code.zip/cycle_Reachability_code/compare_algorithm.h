#pragma once
#ifndef COMPARE_ALGORITHMS_H_
#define COMPARE_ALGORITHMS_H_


//#define paths vector<vector<NODE_TYPE>>

#include "directed_ppl_ns_cycle_reachability.h"
#include <string>
#include <set>
#include <unordered_set>
#include <ostream>
#include <vector>
#include "graph.h"
//#include "k_reach_total_order.h"
struct label_edge {
	int label;
	NODE_TYPE node;
	DIS_TYPE weight;
};


//#include "algorithms.h"
using namespace std;

paths diversify_baseline(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse,int k, NODE_TYPE s, NODE_TYPE t);
void dfs_baseline(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path);
int judge_two_k_repeat_paths_repeat_times(vector<NODE_TYPE>& path1, vector<NODE_TYPE>& path2);
bool judge_k_repeat_paths(vector<NODE_TYPE>& temp_result_path, paths& result, int k);
void test_algorithms(int k, int dis_constraint, string dataset, string query_dataset, string algorithm);
void output_paths(paths& result);
void load_graph_data(string filename, vector<NODE_TYPE >* adjacency_list, vector<NODE_TYPE >* adjacency_list_reverse);
void extractEdges(char str[], NODE_TYPE& x, NODE_TYPE& y);
void dfs_full_state(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, set<NODE_TYPE>& visited_nodes);
void dfs_modified_dfs(vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, int k, int dis_constraint, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, set<NODE_TYPE>& visited_nodes, int& full_state, set<NODE_TYPE>& block_nodes);
bool judge_path_containts_s_t(vector<NODE_TYPE>& path, NODE_TYPE s, NODE_TYPE t);
bool judge_containts_s_t(paths& result, NODE_TYPE s, NODE_TYPE t);
void dfs_cycle_reachability_no_recursive(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, int cur_distance, vector<NODE_TYPE> c_path, bool& reach, int node_num, int dis_constraint);
void dfs_cycle_reachability_with_block(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, bool& reach, set<NODE_TYPE>& blocks, bool& unblock);
void dfs_cycle_reachability(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, bool& reach, int dis_constraint);
bool bfs_non_simple_cycle_reachability(vector<NODE_TYPE>* adj, NODE_TYPE cur_node, NODE_TYPE s, NODE_TYPE t, int dis_constraint, int node_num);
#endif
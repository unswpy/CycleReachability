void dfs_cycle_reachability(bool& first_time, vector<NODE_TYPE>* adjacency_list, NODE_TYPE cur_node, NODE_TYPE query_node1, NODE_TYPE query_node2, paths& result, set<NODE_TYPE> c_path_set, int cur_distance, vector<NODE_TYPE> c_path, bool& reach)
{
	stack<NODE_TYPE> s;
	s.push(cur_node);
	stack<vector<NODE_TYPE>::iterator> s_iter;
	while (!s.empty())
	{
		NODE_TYPE pre = s.top;
		if (c_path_set.find(pre) != c_path_set.end())
		{//repeat vertex
			s.pop();
			s_iter.pop();
			continue;
		}
		if (pre == query_node1 && (!first_time))//should be the second time to touch query_node1
		{

			//if meet a stop nodes

			vector<NODE_TYPE> temp_result_path(c_path);
			temp_result_path.push_back(cur_node);
			//judge whether is repeated or not
			if (judge_containts_s_t(result, query_node1, query_node2))
			{
				result.push_back(temp_result_path);
				reach = true;
				//cout << "find one" << endl;
			}
			s.pop();
			auto iter = s_iter.top();
			NODE_TYPE temp_n = s.top();
			// explore the next vertex, iter++ before entering or after, //before
			while (iter == adjacency_list[temp_n].end() && (!s_iter.empty()))
			{
				s_iter.pop();
				s.pop();
				iter = s_iter.top();
				temp_n = s.top();
			}
			if (s_iter.empty())
			{
				break;
			}
			else {
				iter++;
			}
			continue;
			//return;
		}
		first_time = false;
		auto iter = adjacency_list[pre].begin();
		if (iter == adjacency_list[pre].end())
		{
			s.pop();
			continue;
		}
		else 
		{
			c_path.push_back(*iter);
			c_path_set.insert(*iter);
			s.push(*iter);
			s_iter.push(iter);

		}

	}
	

	
}
